#ifndef __GUARD_POSN__
#define __GUARD_POSN__
struct Posn{
  int x, y;
  Posn(int x, int y);
};
#endif
