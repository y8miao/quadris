#include "posn.h"
Posn::Posn(int x, int y):x(x), y(y){}
